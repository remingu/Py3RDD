class PyRRDError(Exception):
    pass


class ExternalCommandError(PyRRDError):
    pass
